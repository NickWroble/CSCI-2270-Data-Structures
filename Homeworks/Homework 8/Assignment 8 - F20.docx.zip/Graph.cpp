#include "Graph.hpp"

using namespace std;


void Graph::addEdge(string v1, string v2){
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i]->name == v1){
            for(int j = 0; j < vertices.size(); j++){
                if(vertices[j]->name == v2 && i != j){
                    adjVertex av;
                    av.v = vertices[j];
                    vertices[i]->adj.push_back(av);
                    //another vertex for edge in other direction
                    adjVertex av2;
                    av2.v = vertices[i];
                    vertices[j]->adj.push_back(av2);
                }
            }
        }
    }
}

void Graph::addVertex(string name){
    bool found = false;
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i]->name == name){
            found = true;
        }
    }
    if(found == false){
        vertex * v = new vertex;
        v->name = name;
        vertices.push_back(v);
    }
}

void Graph::displayEdges(){
    for(int i = 0; i < vertices.size(); i++){
        cout << vertices[i]->name;
        cout << " --> ";
        for(int j = 0; j < vertices[i]->adj.size(); j++)
            cout << vertices[i]->adj[j].v->name << " ";
        cout << endl;
    }
}

void Graph::breadthFirstTraverse(string sourceVertex){
    for(int i = 0; i < vertices.size(); i++)
        vertices[i]->visited = false;

    vertex *source = vertices[0];
    int i = 0;
    while (source->name != sourceVertex && source){ //get source vertex
        source = vertices[i];
        i++;
    }

    cout << source->name << endl;
    vector<vertex> queue;
    cout << 1 << endl;
    
    queue.push_back(*source);
    source->visited = true;
    vertex *u;
    while(!queue.empty()){
        cout << 1 << endl;
        *u = queue.back();
        cout << 1 << endl;
        cout << u->name << endl;
        cout << 1 << endl;
        queue.pop_back();
        for(i = 0; i < u[0].adj.size(); i++){
            if(!u[0].adj[i].v->visited){
                u[0].adj[i].v->visited = true;
                queue.push_back(*source[0].adj[0].v);
            }
        }
    }
}

int Graph::getConnectedBuildings(){
    
}