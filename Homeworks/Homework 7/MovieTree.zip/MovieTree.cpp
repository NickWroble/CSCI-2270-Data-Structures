#include <iostream>
#include <fstream>
#include "MovieTree.hpp"

using namespace std;

LLMovieNode* getLLMovieNode(int r, std::string t, int y, float q)
{
	LLMovieNode* lmn =new LLMovieNode();
	lmn->ranking = r;
	lmn->title=t;
	lmn->year =y;
	lmn->rating =q;
	lmn->next =NULL;
	return lmn;
}
/* ------------------------------------------------------ */
MovieTree::MovieTree()
{
	root = NULL;
}
/* ------------------------------------------------------ */

void _grader_inorderTraversal(TreeNode * root) {
		if (root == NULL) {
			return;
		}

		_grader_inorderTraversal(root->leftChild);
		cout << root->titleChar << " ";
		_grader_inorderTraversal(root->rightChild);
}


void MovieTree::inorderTraversal() {
	_grader_inorderTraversal(root);
	cout << endl;
}



TreeNode* searchCharHelper(TreeNode* curr, char key)
{
    if (curr == NULL)
        return curr;
    else if(curr->titleChar == key)
        return curr;
    else if (curr->titleChar > key)
        return searchCharHelper(curr->leftChild, key);
    else
        return searchCharHelper(curr->rightChild, key);
}

TreeNode* MovieTree::searchCharNode(char key)
{
    return searchCharHelper(root, key);
}

void showMovieCollectionHelper(TreeNode *node){ //inorder traveral of bst
	if(node == nullptr)
		return;
	showMovieCollectionHelper(node->leftChild);
	LLMovieNode *temp = node->head;
	cout << "Movies starting with letter: " << node->titleChar << endl;
	while(temp != nullptr){ //print out the LL of the BST node
		cout << " >> " << temp->title << " " << temp->rating << endl;
		temp = temp->next;
	}
	showMovieCollectionHelper(node->rightChild);
}

void MovieTree::showMovieCollection(){
	showMovieCollectionHelper(root);
}


TreeNode *newTreeNode(TreeNode *parentNode, LLMovieNode *treeNodeHead){
	TreeNode *newNode 	= new TreeNode();
	newNode->parent 	= parentNode;
	newNode->titleChar 	= treeNodeHead->title[0];
	newNode->head 		= treeNodeHead;
	newNode->leftChild 	= nullptr;
	newNode->rightChild = nullptr;
	return newNode;
}

void insertMovieHelper(TreeNode *currentRoot, LLMovieNode *newMovie){
	if(currentRoot->titleChar == newMovie->title[0]){ //check if the current root's char matches the newMovie's title char
		if(currentRoot->head == nullptr || currentRoot->head->title >= newMovie->title){
			newMovie->next = currentRoot->head;
			currentRoot->head = newMovie;
		}
		else{
			LLMovieNode *curr = currentRoot->head;
			while (curr->next != nullptr && curr->next->title < newMovie->title)
				curr = curr->next;
			newMovie->next = curr->next;
			curr->next = newMovie;
		}
	}
	else if(currentRoot->titleChar > newMovie->title[0]){ //go left in BST
		if(currentRoot->leftChild == nullptr){ //left child does not exist
			TreeNode *newNode 		= new TreeNode;
			newNode 				= newTreeNode(currentRoot, newMovie);
			newNode->head 			= newMovie;
			currentRoot->leftChild 	= newNode;
		}
		else 
			insertMovieHelper(currentRoot->leftChild, newMovie);
	}
	else if(currentRoot->titleChar < newMovie->title[0]){ //go right  in BST
		if(currentRoot->rightChild == nullptr){ //right child does not exist
			TreeNode *newNode 		= new TreeNode;
			newNode 				= newTreeNode(currentRoot, newMovie);
			newNode->head 			= newMovie;
			currentRoot->rightChild = newNode;
		}
		else 
			insertMovieHelper(currentRoot->rightChild, newMovie);
	}
}

void MovieTree::insertMovie(int ranking, std::string title, int year, float rating){
	LLMovieNode *newMovie 	= new LLMovieNode;
	newMovie->ranking 		= ranking;
	newMovie->title			= title;
	newMovie->year 			= year;
	newMovie->rating 		= rating;
	newMovie->next 			= nullptr;
	if(root == nullptr)
		root = newTreeNode(nullptr, newMovie);
	else
		insertMovieHelper(root, newMovie);
}

void MovieTree::leftRotation(TreeNode* curr){
	if(curr->rightChild == nullptr)
		return;
	TreeNode *temp = curr->rightChild;
	if(curr == root)
		root = temp;
	else if(curr->parent->leftChild == curr)
		curr->parent->leftChild = temp;
	else
		curr->parent->rightChild = temp;
	curr->rightChild = temp->leftChild;
	if(temp->leftChild)
		temp->leftChild->parent = curr;
	temp->leftChild = curr;
	temp->parent = curr->parent;
	curr->parent = temp;
}

TreeNode *minValue(TreeNode *root){
	TreeNode *curr = root;
	while (curr->leftChild != nullptr)
		curr = curr->leftChild;
	return curr;
}


TreeNode *maxValue(TreeNode *root){
	TreeNode *curr = root;
	while (curr->rightChild != nullptr)
		curr = curr->rightChild;
	return curr;
}

TreeNode *getInorderSuccessor(TreeNode *root, TreeNode *node){
	if(node->rightChild != nullptr)
		return minValue(node->rightChild);
	TreeNode *parent = node->parent;
	while(parent != nullptr){
		node = parent;
		parent = parent->parent;
	}
	return parent;
}

TreeNode* findHelper(TreeNode* tempP, TreeNode* temp) {
  if (tempP->titleChar == temp->titleChar) {
    return tempP;
  } else {
    if (tempP->titleChar < temp->titleChar) {
      return findHelper(tempP->rightChild, temp);
    }
    if (tempP->titleChar > temp->titleChar) {
      return findHelper(tempP->leftChild, temp);
    }
  }
}

TreeNode* findParent(TreeNode* temp, TreeNode* root) {
  TreeNode* tempP = findHelper(root, temp);
  if (tempP->rightChild == temp || tempP->leftChild == temp) {
    return temp;
  } else {
    return NULL;
  }
}

void removeNode(TreeNode* temp, TreeNode* root) {
  if (temp->rightChild == NULL && temp->leftChild == NULL) {
    TreeNode* tempP = findParent(temp, root);
    temp = NULL;
  } else if (temp->rightChild == NULL && temp->leftChild != NULL) {
    TreeNode* min = minValue(temp->rightChild);
    temp = min;
    min = NULL;
  } else if (temp->rightChild != NULL && temp->leftChild == NULL) {
    TreeNode* max = maxValue(temp->leftChild);
    temp = max;
    max = NULL;
  } else {
    TreeNode* max = maxValue(temp->leftChild);
    temp = max;
    max = NULL;
  }
}

void MovieTree::removeMovieRecord(std::string title) {
  TreeNode* searched = new TreeNode;
  searched = searchCharNode(title[0]);
  if (searched != NULL) {
	LLMovieNode* crawler = searched->head;
	LLMovieNode* prev = crawler;
	while (crawler != NULL) {
		if (crawler->title == title && crawler == searched->head) {
			if (crawler->next == NULL) {
				delete crawler;
				searched->head = NULL;
				removeNode(searched, root);
			}
			else {
				searched->head = crawler->next;
				delete crawler;
				}
			} 
			else if (crawler->title == title) {
				prev->next = crawler->next;
				delete crawler;
			} 
			else {
				prev = crawler;
				crawler = crawler->next;
			}
		}
	}
	else
		cout << "Movie not found." << endl;
}

MovieTree::~MovieTree(){
}